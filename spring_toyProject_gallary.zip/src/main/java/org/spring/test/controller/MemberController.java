package org.spring.test.controller;

import java.io.PrintWriter;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spring.test.domain.MemberVO;
import org.spring.test.service.MemberService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping(value="/member/*")
public class MemberController {	
	private static final Logger logger = LoggerFactory.getLogger(MemberController.class);
	
	@Inject
	private MemberService service;
	
	// ȸ������ get
	@RequestMapping(value="/register", method=RequestMethod.GET)
	public void getRegister() throws Exception{
		logger.info("get register");
	}
	
	// ȸ������ post
	@RequestMapping(value="/register", method=RequestMethod.POST)
	public String postRegister(MemberVO vo, RedirectAttributes rttr) throws Exception{
		logger.info("post register");
		int result = service.idChk(vo);
		
//		try {
			if(result == 1) {
				return "/member/register";
			} else if(result == 0) {
				
				service.register(vo);
			}
//		} catch(Exception e) {
//			throw new RuntimeException();
//		}

		System.out.println("회원가입 성공");
		rttr.addFlashAttribute("msg", "회원가입 성공");

		return "redirect:/";
	}
	
	// �α��� post
	@RequestMapping(value="/login", method=RequestMethod.POST)

	public void login(MemberVO vo, HttpServletRequest req, HttpServletResponse response, RedirectAttributes rttr, Model model) throws Exception{		

		logger.info("post login");
		
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();		
		HttpSession session = req.getSession();
		MemberVO login = service.login(vo);

		
		if(login == null) {
			session.setAttribute("member", null);

			rttr.addFlashAttribute("msg", false);

			out.println("<script>alert('아이디나 비밀번호를 확인해주세요'); location.href='/login';</script>");
			out.flush();	

		} else {
			rttr.addFlashAttribute("msg", "로그인 성공!");

			session.setAttribute("member", login);

			out.println("<script>alert('로그인 성공'); location.href='/';</script>");
			out.flush();	
		}
		

//			req.setAttribute("msg", "성공");
//			model.addAttribute("msg", "성공");
//			message = "<script>alert('success');location.href='redirect:/'</script>";
		

//		return message;

	}
	
	// �α׾ƿ�
	@RequestMapping(value="/logout", method=RequestMethod.GET)
	public String logout(HttpSession session) throws Exception{
		session.invalidate();
		
		return "redirect:/";
	}
	
	// ȸ������ ����
	@RequestMapping(value="/memberUpdateView", method=RequestMethod.GET)
	public String registerUpdateView() throws Exception{
		return "member/memberUpdateView";
	}
	
	// ȸ������ ����
	@RequestMapping(value="/memberUpdate", method=RequestMethod.POST)
	public String registerUpdate(MemberVO vo, HttpSession session) throws Exception{
		service.memberUpdate(vo);
		session.invalidate();
		
		return "redirect:/";
	}
	
	// ȸ�� Ż�� get
	@RequestMapping(value="/memberDeleteView", method=RequestMethod.GET)
	public String memberDeleteView() throws Exception{
		return "member/memberDeleteView";
	}
	
	// ȸ�� Ż�� post
	@RequestMapping(value="/memberDelete", method=RequestMethod.POST)
	public String memberDelete(MemberVO vo, HttpSession session, RedirectAttributes rttr) throws Exception{
		// ���ǿ� �ִ� member�� ������ member������ �־��ش�
		MemberVO member = (MemberVO) session.getAttribute("member");
		System.out.println("여기 지나가냐?");
		// ���ǿ� �ִ� ��й�ȣ
		String sessionPw = member.getUserPw();
		
		// vo�� ������ ��й�ȣ
		String voPw = vo.getUserPw();
		
		if(!(sessionPw.equals(voPw))) {
			rttr.addFlashAttribute("msg", false);
			
			return "redirect:/member/memberDeleteView";
		}
		
		service.memberDelete(vo);
		session.invalidate();
		return "redirect:/";
	}
	
	// �н����� üũ
	@ResponseBody
	@RequestMapping(value="/passChk", method=RequestMethod.POST)
	public int passChk(MemberVO vo) throws Exception{
		int result = service.passChk(vo);
		return result;
	}
	
	// ���̵� �ߺ� üũ
	@ResponseBody
	@RequestMapping(value="/idChk", method=RequestMethod.POST)
	public int idChk(MemberVO vo) throws Exception{
		int result = service.idChk(vo);
		return result;
	}
}




