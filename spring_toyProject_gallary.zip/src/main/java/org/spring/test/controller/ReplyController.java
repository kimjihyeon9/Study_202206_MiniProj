package org.spring.test.controller;

import java.util.List;

import javax.inject.Inject;

import org.spring.test.domain.BoardVO;
import org.spring.test.domain.Page;
import org.spring.test.domain.ReplyVO;
import org.spring.test.service.BoardService;
import org.spring.test.service.ReplyService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
@RequestMapping("/reply/*")
public class ReplyController {
	
	@Inject
	private ReplyService replyService;
	
	
	
	// ��� �ۼ�
	@RequestMapping(value = "/write", method = RequestMethod.POST)
	private String posttWirte(ReplyVO vo) throws Exception {
	  //  vo.setPassowrd("hou");
	    replyService.write(vo);
	    return "redirect:/board/view?bno=" + vo.getBno();
	}
	
	// ��� ����
	@RequestMapping(value="/delete", method=RequestMethod.GET)
	public String getDelete(ReplyVO vo) throws Exception{
		replyService.delete(vo);
		 return "redirect:/board/view?bno=" + vo.getBno();
	}
	
	
	// ��� ����
		@RequestMapping(value="/modify", method=RequestMethod.GET)
		public String getmodify(ReplyVO vo) throws Exception{
			System.out.println(vo.getReplypassword());
			replyService.modify(vo);
			return "redirect:/board/view?bno=" + vo.getBno();
		}

}
