package org.spring.test.dao;

import java.util.HashMap;
import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.spring.test.domain.BoardVO;
import org.spring.test.domain.ReplyVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class replyDAOImpl implements replyDAO {
	
	@Autowired
	private SqlSession sql;
	
	private static String namespace = "org.spring.test.mapper.reply";

	@Override
	public List<ReplyVO> list(int bno) throws Exception {
		// TODO Auto-generated method stub
		return sql.selectList(namespace + ".replyList",bno);
	}

	@Override
	public void write(ReplyVO vo) throws Exception {
		// TODO Auto-generated method stub
		sql.insert(namespace+".replyWrite",vo);
	}
	@Override
	public void modify(ReplyVO vo) throws Exception {
		// TODO Auto-generated method stub
		sql.update(namespace+".replyWrite",vo);
	}
	@Override
	public void delete(ReplyVO vo) throws Exception {
		// TODO Auto-generated method stub
		sql.delete(namespace+".replyDelete",vo);
	}

}
