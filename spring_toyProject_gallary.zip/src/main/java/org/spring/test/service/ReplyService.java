package org.spring.test.service;

import java.util.List;

import org.spring.test.domain.BoardVO;
import org.spring.test.domain.ReplyVO;

public interface ReplyService {
	// �Խù� �ۼ�
	public void write(ReplyVO vo) throws Exception;
	
	// �Խù� ��ȸ
	public List<ReplyVO> list(int bno) throws Exception;
	
	// �Խù� ����
	public void modify(ReplyVO vo) throws Exception;
	
	// �Խù� ����
	public void delete(ReplyVO vo) throws Exception;
}

