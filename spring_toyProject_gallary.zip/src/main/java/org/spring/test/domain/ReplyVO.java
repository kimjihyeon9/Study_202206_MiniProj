package org.spring.test.domain;

import java.util.Date;

public class ReplyVO {
	
	private int rno;
	private int bno;
	private String writer;
	private String content;
	private Date regdate;
	private String replypassword;
	
	public int getRno() {
		return rno;
	}
	public void setRno(int rno) {
		this.rno = rno;
	}
	public int getBno() {
		return bno;
	}
	public void setBno(int bno) {
		this.bno = bno;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getRegdate() {
		return regdate;
	}
	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}
	public String getReplypassword() {
		return replypassword;
	}
	public void setReplypassword(String replypassword) {
		this.replypassword = replypassword;
	}
	
	
	/*
	 * 
	CREATE TABLE tbl_reply (
    rno         int             not null auto_increment,
    bno         int             not null,
    writer     varchar(30) not null,
    content     text             not null,
    regDate     timestamp     not null default now(),
    replypassword text             not null,
    PRIMARY KEY(rno, bno),
    FOREIGN KEY(bno) REFERENCES tbl_board(bno) ON DELETE CASCADE
);
	 * 
	 */
	
}
