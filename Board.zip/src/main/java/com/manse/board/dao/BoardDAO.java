package com.manse.board.dao;

import java.util.List;

public interface BoardDAO {
	public List list() throws Exception;
}
