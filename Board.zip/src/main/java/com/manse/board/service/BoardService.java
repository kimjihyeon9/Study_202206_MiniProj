package com.manse.board.service;

import java.util.List;

public interface BoardService {
	public List list() throws Exception;
}
